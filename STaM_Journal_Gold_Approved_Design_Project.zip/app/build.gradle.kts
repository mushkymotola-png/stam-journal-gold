plugins { id("com.android.application") }
android { namespace = "il.stam.journal"; compileSdk = 35
 defaultConfig { applicationId = "il.stam.journal.goldedition"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "3.0" } }
